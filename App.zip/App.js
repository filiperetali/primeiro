
import { FlatList, StyleSheet, Text, View } from 'react-native';
import Topo from './sources/telas/Carrinho/Topo';
import Detalhes from './sources/telas/Carrinho/Detalhes';
import Mocks from './sources/mocks/carrinho';
import Item from './sources/telas/Carrinho/Item';

export default function App() {
  return (
    <View style={styles.container}>
      <Topo {...Mocks.topo}/>
      <Detalhes {...Mocks.detalhes} />

      <FlatList 
        data={Mocks.itens.lista}
        renderItem={Item}
        keyExtractor={({nome})=>nome}

      />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    
  },
});

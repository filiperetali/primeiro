
import { Image, StyleSheet, Text, View } from 'react-native';

export default function Detalhes({titulo, preco, imagem}) {
  return (
    <View style={styles.container}>
      <Text>{titulo}</Text>
      <Text>{preco}</Text>
      <Image 
        source={imagem}
        style={styles.imagem}
      />
      
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },imagem:{
    height:30, width:30
  }
});

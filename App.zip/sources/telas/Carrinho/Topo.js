
import { StyleSheet, Text, View, Image } from 'react-native';

export default function Topo({titulo, imagem}) {
  return (
    <View style={styles.container}>
      <Text>{titulo}</Text>      
      <Image 
        source={imagem}
        style={styles.imagem}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  imagem:{
    height:30, width:30
  }
});
